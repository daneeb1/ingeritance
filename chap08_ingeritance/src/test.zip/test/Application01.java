package test;

import java.util.Scanner;

public class Application01 {

   public static void main(String[] args) {
	   
	/* 1. 주제 한가지를 선정한다.
	전자제품 판매점

	2. 상속을 이용하여 세분화 한다.
	ex) 제품 -> 컴퓨터 /  제품 -> 냉장고

	3. 공통기능을 도출하고 상속을 받아 개별 기능을 확장한다.
	ex) 컴퓨터.전기(100w)/ 냉장고.전기(50w)소비

	4. 오버로딩을 이용하여 기능을 다양하게 만든다.
	ex) 컴퓨터.키입력(String or int) = 문자 입력 혹은 숫자 입력
	ex) 냉장고.온도조절(String or int) = "김치냉장고모드", 숫자입력

	5. main에서 사용자가 기능을 조작할 수 있도록 만든다.

	is a 관계 기술
	생성자 get /set / toString */
      
      Scanner sc = new Scanner(System.in);   
      
      menu:
      while(true) {
         System.out.println("======== 환영합니다 고객님 ======");
         System.out.println("1. 전자레인지");
         System.out.println("2. 에어컨");
         System.out.println("3. 프로그램 종료");
         int no = sc.nextInt(); // 입력을 받음
         
        switch(no) {
        	case 1 : MicroWave(); break;
        	case 2 : AirConditioner(); break;
        	case 3 : System.out.println("프로그램을 종료합니다."); break menu;
        	default : System.out.println("잘못된 번호를 입력하였습니다."); break;
        	}
 
         
      }  
   sc.close();

   }

   

private static void MicroWave() {
	MicroWave Mic = new MicroWave("MWO-E8A01", "SK매직", 800, 67620);	
	System.out.println(Mic.toString()+"\n");
	Mic.on();
	Mic.set();
	Mic.movement();
	Mic.time();
	Mic.stop();
   }

private static void AirConditioner() {
	AirConditioner Air = new AirConditioner("AF17B6474GZS", "삼성전자", 2.2, 284380);
	System.out.println(Air.toString()+"\n");

	Air.on();
	Air.set();
	Air.movement();
	Air.time();
	Air.stop();
}

	
}

